package com.example.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.BoardVO;
import com.example.domain.Criteria;
import com.example.domain.PageMaker;
import com.example.mapper.BoardDAO;
import com.example.service.BoardService;

//20211027 ������
@Controller
public class BoardController {
	@Autowired
	BoardDAO bdao;
	
	@Autowired
	BoardService service;
	
	@RequestMapping("/insert")
	public String insert(Model model){
		model.addAttribute("pageName", "insert.jsp");
		return "home";
	}
	
	@RequestMapping("/list.json")
	@ResponseBody
	public HashMap<String, Object> listJSON(Criteria cri){
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("list", bdao.list(cri));
		
		PageMaker pm = new PageMaker();
		pm.setCri(cri);
		pm.setTotalCount(120);
		map.put("cri", cri);
		map.put("pm", pm);
		return map;
	}
	
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String insertPost(BoardVO vo){
		System.out.println(vo.toString());
		service.insert(vo);
		return "redirect:list";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String updatePost(BoardVO vo){
		System.out.println(vo.toString());
		service.update(vo);
		return "redirect:list";
	}
	
	@RequestMapping("/read")
	public String read(int id, Model model){
		model.addAttribute("pageName", "read.jsp");
		model.addAttribute("vo", bdao.read(id));
		return "read";
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public String deletePost(int id) {
		System.out.println(id);
		service.delete(id);
		return "redirect:list";
	}
}
