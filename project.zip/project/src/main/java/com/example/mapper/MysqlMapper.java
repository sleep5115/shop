package com.example.mapper;

public interface MysqlMapper {
	public String getTime();
}
