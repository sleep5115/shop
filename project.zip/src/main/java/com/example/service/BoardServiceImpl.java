package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domain.BoardVO;
import com.example.mapper.BoardDAO;

@Service
public class BoardServiceImpl implements BoardService{
	@Autowired
	BoardDAO bdao;
	
	@Transactional
	@Override
	public void insert(BoardVO vo) {
		bdao.insert(vo);
		String[] files = vo.getFiles();
		if(files == null) return;
		for(String fullName : files) {
			bdao.addAttach(fullName);
		}
		
		bdao.newattachcount();
	}

	@Transactional
	@Override
	public void update(BoardVO vo) {
		bdao.update(vo);
		
		// ���� ÷������ ����
		int id = vo.getId();
		bdao.deleteAttach(id);
		
		// ÷������ ���
		String[] files = vo.getFiles();
		
		if (files != null) {
			for (String fullName : files) {
				bdao.replaceAttach(id, fullName);
			}
		}
		
		bdao.attachcount(id);
	}
	
	@Transactional
	@Override
	public void delete(int id) {
		bdao.deleteAttach(id);
		bdao.delete(id);
	}
}
